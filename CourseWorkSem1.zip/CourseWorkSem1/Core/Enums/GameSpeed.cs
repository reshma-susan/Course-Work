﻿public enum GameSpeed
{
    VerySlow =1000,
    Slow = 500,
    Fast = 200,
    VeryFast = 100
}