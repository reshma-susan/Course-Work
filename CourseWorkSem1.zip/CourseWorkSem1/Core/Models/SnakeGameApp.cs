﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Core.Models
{
    [Serializable]
    public class SnakeGameApp
    {

        private Game Game;

        public SnakeGameApp(GameSpeed speed)
        {
            Game = new Game(speed);
        }

        public bool Run()
        {
            var finished = false;
            while (!finished)
            {
                Game.Draw();
                Game.Play();
                finished = Game.Quit;
                if (Game.Pause)
                {
                    return true;
                }
                if (Game.Lost)
                {
                    Console.WriteLine("\nYou lost.");
                    Thread.Sleep(10000);
                    return false;
                }
            }

            return false;
        }
    }
}
