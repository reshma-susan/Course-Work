﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models
{
    [Serializable]
    public class Board
    {
        public static DirectionMap DirectionMap { get; } = new DirectionMap();

        private readonly string instructions = "How to Play: Avoid hitting walls or yourself. Grow by eating food (@). Highest length wins.";
        private readonly string commandBase = "Commands: {0}, Esc: Quit , End: Save to state\n";
        private readonly string lengthBase = "Length: {0}\n";

        private Pixels[,] grid;
     
        private int leftEdgeX => 0;
        private int rightEdgeX => Width - 1;
        private int topEdgeY => 0;
        private int bottomEdgeY => Height - 1;

        public Snake Snake { get; private set; }
        public int Height { get; private set; }
        public int Width { get; private set; }
        public Pixels Current => Snake.Head;
        public Pixels Center => get(Width / 2, Height / 2);
        public Pixels Food { get; private set; }
        public bool HasCollided { get; private set; }

        public Board(int width = 90, int height = 25)
        {
            Width = width;
            Height = height;
            grid = new Pixels[Width, Height];
            initGrid();
        }

        public void DoTurn()
        {
            doTurn(Snake.Direction, getDestination(Snake.Direction));
        }

        public void DoTurn(Command direction)
        {
            doTurn(direction, getDestination(direction));
        }

        public void Draw()
        {
            Console.SetCursorPosition(0, 0);
            Console.WriteLine(ToString());
        }

        public void Add(Snake snake) => Snake = snake;
        public void AddFood() => randomCell().SetFood();

        public Pixels TopNeighbor(Pixels cell) => grid[cell.X, cell.Y - 1];
        public Pixels RightNeighbor(Pixels cell) => grid[cell.X + 1, cell.Y];
        public Pixels BottomNeighbor(Pixels cell) => grid[cell.X, cell.Y + 1];
        public Pixels LeftNeighbor(Pixels cell) => grid[cell.X - 1, cell.Y];

        public override string ToString()
        {
            var sb = new StringBuilder();
           
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    sb.Append(grid[x, y].Value);
                }
                sb.Append("\n"); 
            }
            sb.AppendFormat(lengthBase, Snake.Length);
            sb.AppendLine(instructions);
            sb.AppendFormat(commandBase, DirectionMap.ToString());
            return sb.ToString();
        }

        private Pixels get(int x, int y) => grid[x, y];

        private void add(Pixels cell) => grid[cell.X, cell.Y] = cell;

        private bool isBorder(Pixels cell) => cell.X == leftEdgeX || cell.X >= rightEdgeX
                                         || cell.Y == topEdgeY || cell.Y >= bottomEdgeY;

        private void doTurn(Command direction, Pixels target)
        {
            if (isLegalMove(direction, target))
            {
                Snake.Move(direction, target);

                if (Snake.HasEaten)
                {
                    Snake.Grow(getNewTail());
                    AddFood();
                }

                Draw();
            }
        }

        private bool isLegalMove(Command direction, Pixels target)
        {
            if (direction.IsOpposite(Snake.Direction))
            {
                return false;
            }

            HasCollided = target.IsForbidden;

            return !HasCollided;
        }

        private Pixels getDestination(Command direction) => getDirectionalNeighbor(Snake.Head, direction);

        private Pixels getNewTail() => getDirectionalNeighbor(Snake.Tail, Snake.Direction.Opposite);

        private Pixels getDirectionalNeighbor(Pixels cell, Command direction)
        {
            var neighbor = new Pixels(-1, -1); 

            if (direction.IsUp)
            {
                neighbor = TopNeighbor(cell);
            }
            else if (direction.IsRight)
            {
                neighbor = RightNeighbor(cell);
            }
            else if (direction.IsDown)
            {
                neighbor = BottomNeighbor(cell);
            }
            else if (direction.IsLeft)
            {
                neighbor = LeftNeighbor(cell);
            }

            return neighbor;
        }

        private Pixels randomCell()
        {
            bool isEmpty;
            var cell = new Pixels(-1, -1); 
            Random random = new Random();
            do
            {
                cell = grid[random.Next(Width), random.Next(Height)];
                isEmpty = cell.IsEmpty;
            } while (!isEmpty);

            return cell;
        }

        private void initGrid()
        {
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    var cell = new Pixels(x, y);

                    add(cell);

                    if (isBorder(cell))
                    {
                        cell.SetBorder();
                    }
                    else
                    {
                        cell.SetEmpty();
                    }
                }
            }
        }
    }
}
