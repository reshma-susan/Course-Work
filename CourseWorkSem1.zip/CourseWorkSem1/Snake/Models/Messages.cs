﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake.Models
{
    public static class Messages
    {
        public const string IntroMessage = "Hello, welcome to the snake game. Please enter your profile if exists. Else will create a new profile based on passed name.";

        public const string SavedStates = "Please find the below saved states and enter in next step to proceed.";

        public const string StoredStates = "Please select from stored states if you want to procced, else if passed state is not present it will be created and used.";

        public const string NoStoredStates = "Please add a new state name to proceed.";

        public const string Delimiter = "--------------------------------------------------------------------------------";


        public const string SppedSelector = "Please enter the speed of game as required. 1 - VerySlow , 2 - Slow , 3 - Fast , 4 - VeryFast";

        public const string SppedSelectorError = "Invalid speed selected, defaulting to Slow.";
    }
}
